#########################################################################################################################
# Author: Hiren Karathia																								#
# Last time Modified: 02/25/2017-5:00PM Saturday																		#
# This script is designed to map Read coverage over the exonic region of transcript of Human Gene.						#
#########################################################################################################################

import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib
import os, re, sys

def getGlobalArrays():
	"""
	General function to get global Hash Variable
	"""
	global GENE_TR_ARRAY, TR_CHR_ARRAY, TR_EXN_ST_ARRAY, TR_EXN_EN_ARRAY, TR_EXN_NO_ARRAY, TR_EXN_STRAND_ARRAY, TR_GENE_ARRAY
	GENE_TR_ARRAY = {} 
	TR_GENE_ARRAY = {}
	TR_CHR_ARRAY = {}
	TR_EXN_ST_ARRAY = {}
	TR_EXN_EN_ARRAY = {}
	TR_EXN_NO_ARRAY = {}
	TR_EXN_STRAND_ARRAY = {}
	return GENE_TR_ARRAY, TR_CHR_ARRAY, TR_EXN_ST_ARRAY, TR_EXN_EN_ARRAY, TR_EXN_NO_ARRAY, TR_EXN_STRAND_ARRAY, TR_GENE_ARRAY

def getGenesIsoform(arr, k, v):
	if k in arr.keys():
		temp = arr[k]
	else:
		temp = []
	if v not in temp:
		temp.append(v)
	arr[k] = temp
	return arr

def getNonUniqueArray(arr, k, v):
	if k in arr.keys():
		temp = arr[k]
	else:
		temp = []
	temp.append(v)
	arr[k] = temp
	return arr	
	
def getReferenceData(fl):
	"""
	Store Reference data in to the global library varaibles.
	"""
	data = np.loadtxt(fl, dtype='S', delimiter='\t').astype(str)
	header = data[0]
	data = data[1:]
	for i in range(data.shape[0]):
		getGenesIsoform(GENE_TR_ARRAY, data[i][0], data[i][1])
		getGenesIsoform(TR_CHR_ARRAY, data[i][1], data[i][3])
		getGenesIsoform(TR_EXN_ST_ARRAY, data[i][1], int(data[i][4]))
		getGenesIsoform(TR_EXN_EN_ARRAY, data[i][1], int(data[i][5]))
		getGenesIsoform(TR_EXN_NO_ARRAY, data[i][1], int(data[i][6]))
		getGenesIsoform(TR_EXN_STRAND_ARRAY, data[i][1], data[i][7])
		getGenesIsoform(TR_GENE_ARRAY, data[i][1], data[i][0])
		
def getNewImage(s1, s2, col):
	"""
	This function is prepared to get New Image object. input variable s1 and s2 can be changed to adjust figure size. Currently 'col' variable is statis for this function.
	"""
	im = Image.new('RGBA', (s1, s2), "white")
	draw = ImageDraw.Draw(im)   
	return im, draw

def getNewRGBImage(s1, s2, col):
	im = Image.new('RGB', (s1, s2), col)
	draw = ImageDraw.Draw(im)   
	return im, draw  
  
def drawBox(draw, x1, y1, x2, y2, fill):
	box = [(x1,y1), (x2,y2)]	
	draw.rectangle(box, fill)
	return draw

def getFontFile():
	fontfl = os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data/fonts/ttf/DejaVuSerif.ttf")
	font = ImageFont.truetype(fontfl, 20)
	tr_font = ImageFont.truetype(fontfl, 10)
	return font, tr_font
	
def drawLine(draw, x1, y1, x2, y2, fill):
	ln = [(x1, y1), (x2, y2)]	
	draw.line(ln, fill)
	return draw

def drawReverseTriangle(x, y, draw, excolor):
	"""
	the arrow edge is fixed. But can be changed as per need of extension of arrow.
	"""
	x1 = x - 10
	y1 = y
	x2 = x
	y2 = y - 10
	x3 = x
	y3 = y + 10
	draw.polygon([(x1,y1), (x2,y2), (x3, y3)], fill = excolor)
	return draw
	
def drawForwardTriangle(x, y, draw, excolor):
	x1 = x + 10
	y1 = y
	x2 = x
	y2 = y - 10
	x3 = x
	y3 = y + 10
	draw.polygon([(x1,y1), (x2,y2), (x3, y3)], fill = excolor)
	return draw	

def getColorCutoff(val):
	if val <= 200:
		col = (206, 26, 59)
	else:
		col = (118, 229, 27)
	return col	
	
def drawTranscriptTrack(EX_LEN, track_start_x, track_end_x, track_start_y, track_end_y, st_first_exon, exn_height, intron_gap, lncolor, excolor, im, draw, strand, strand_text_pos_s, strand_text_pos_e, gnfont, READ_POS_ARRAY, READ_TMLT_ARRAY, READ_ORI_ARRAY):
	"""
	Master function for preparing Exon level visualization for each transcript.
	"""
	st = track_start_x + st_first_exon
	draw = drawLine(draw, track_start_x, track_start_y, track_end_x, track_end_y, lncolor)
	if strand == "+":
		draw.text((strand_text_pos_s, track_start_y-5), "5'", (0,0,0), font=gnfont)
		draw.text((strand_text_pos_e, track_start_y-5), "3'", (0,0,0), font=gnfont)
	else:
		draw.text((strand_text_pos_s, track_start_y-5), "3'", (0,0,0), font=gnfont)
		draw.text((strand_text_pos_e, track_start_y-5), "5'", (0,0,0), font=gnfont)
	bx_y0 = track_start_y-(exn_height/2)
	bx_y1 = track_start_y+(exn_height/2)
	for i in range(EX_LEN.shape[0]):
		draw = drawBox(draw, st, bx_y0, st+EX_LEN[i], bx_y1, excolor)
		if i in READ_POS_ARRAY.keys():
			ex_percent = READ_POS_ARRAY[i][0]
			tm_values = READ_TMLT_ARRAY[i][0]
			read_ori = READ_ORI_ARRAY[i][0]
			rdist = np.abs(st+EX_LEN[i] - st)
			for k in range(ex_percent.shape[0]):
				rex_dist = int(float(rdist*ex_percent[k])/100)
				#draw = drawLine(draw, st+rex_dist, bx_y0-30, st+rex_dist, bx_y0-10, lncolor)
				rcolor = getColorCutoff(tm_values[k])
				r_direct = read_ori[k]
				if r_direct == "+":
					draw = drawBox(draw, st+rex_dist, bx_y0-20, st+rex_dist+3, bx_y0-10, rcolor)
				else:
					draw = drawBox(draw, st+rex_dist, bx_y1+20, st+rex_dist+3, bx_y1+10, rcolor)
		if strand == "+":
			draw = drawForwardTriangle(st+EX_LEN[i], track_start_y, draw, excolor)
		else:
			draw = drawReverseTriangle(st, track_start_y, draw, excolor)
		st = st+EX_LEN[i]+intron_gap
	return im, draw

def getReadOverlayExon(SS, RSM, REM, ES, EX_COV, TMPLTSM, RDIRECTM, strand):
	"""
	Function for overlaying read over each exons as per input data.
	"""
	idx = np.hstack(np.array([np.where(np.logical_and(RSM[i] >= ES[:,0], RSM[i] <= ES[:,1]))[0].shape[0] for i in range(RSM.shape[0])]))
	#idx1 = np.hstack(np.array([np.where(np.logical_or(np.logical_and(ES[:,0] > RS[i], RE[i] > ES[:,0]), np.logical_and(ES[:,1] > RS[i], RE[i] > ES[:,1]))) for i in range(RS.shape[0])]))
	idx1 = np.hstack(np.array([np.where(np.logical_and(ES[:,0] > RSM[i], REM[i] > ES[:,0]))[0].shape[0] for i in range(RSM.shape[0])]))
	RS = RSM[np.where(idx > 0)[0]]
	TMPLTS = TMPLTSM[np.where(idx > 0)[0]]
	RDIRECT = RDIRECTM[np.where(idx > 0)[0]]
	if np.where(idx1 > 0)[0].shape[0]:
		RS = np.hstack((RS, np.hstack(REM[np.where(idx1 > 0)[0]]))) # This condition checking if for checking if the read partially overlap to the end of Exons
		TMPLTS = np.hstack((TMPLTS, np.hstack(TMPLTSM[np.where(idx1 > 0)[0]])))
		RDIRECT = np.hstack((RDIRECT, np.hstack(RDIRECTM[np.where(idx1 > 0)[0]])))
	RLEN = {}
	ELEN = {}
	COVF = {}
	TMPL = {}
	RORI = {}
	for i in range(RS.shape[0]):
		if np.where(np.logical_and(ES[:,0] <= RS[i], ES[:,1] >= RS[i]))[0].shape[0] > 0:
			tidx = np.where(np.logical_and(ES[:,0] <= RS[i], ES[:,1] >= RS[i]))[0][0]
			if strand == "+":
				rdist = RS[i] - ES[tidx][0]
			else:
				rdist = ES[tidx][1] - RS[i]
			
			#rdist = RS[i] - ES[tidx][0]	
			covf = EX_COV[tidx]
			exlen = np.abs(ES[tidx][1] - ES[tidx][0]) + 1
			ELEN = getGenesIsoform(ELEN, tidx, exlen)
			TMPL = getGenesIsoform(TMPL, tidx, TMPLTS[i])
			RLEN = getGenesIsoform(RLEN, tidx, rdist)
			COVF = getGenesIsoform(COVF, tidx, covf)
			RORI = getNonUniqueArray(RORI, tidx, RDIRECT[i])
	FINAL_READ_ARRAY = {}
	FINAL_TEMP_ARRAY = {}
	FINAL_ORI_ARRAY = {}
	exlist = np.array(list(ELEN.keys()))
	tmlist = np.array(list(TMPL.values()))
	colist = np.array(list(COVF.keys()))
	orilist = np.array(list(RORI.values()))
	r_cov_percent = np.array([(np.array(RLEN[exlist[i]], dtype='f')/ELEN[exlist[i]][0])*100 for i in range(exlist.shape[0])])
	for i in range(r_cov_percent.shape[0]):
		FINAL_READ_ARRAY = getGenesIsoform(FINAL_READ_ARRAY, exlist[i], r_cov_percent[i])
		FINAL_TEMP_ARRAY = getGenesIsoform(FINAL_TEMP_ARRAY, exlist[i], tmlist[i])
		FINAL_ORI_ARRAY = getGenesIsoform(FINAL_ORI_ARRAY, exlist[i], orilist[i])
	return FINAL_READ_ARRAY, FINAL_TEMP_ARRAY, FINAL_ORI_ARRAY
	
	
def getReadData(fl, outdir):
	"""
	Master function for read and process the data for each samples. Each samples #of Transcripts process one by one and at the end this function create figures for each sample and store into the output directory. 
	"""
	flankgap = 850
	lncolor = (30, 7, 19)
	excolor = (131, 156, 219)
	data = np.loadtxt(fl, dtype='S', delimiter='\t').astype(str)
	header = data[0]
	data = data[1:]
	USAMPLE = np.unique(data[:,0])
	font, gnfont = getFontFile()
	for us in USAMPLE:
		S = data[np.where(us == data[:,0])]
		S = S[np.argsort(S[:,2])]
		UGENEID = np.unique(S[:,2])
		UTRANSID = np.unique(S[:,3])
		tr_image_v_gap = 50
		im, draw = getNewRGBImage(1000, 2500, "white")
		sam_id = "Sample: " + str(us)
		draw.text((20, 30), sam_id, (0,0,0), font=font)
		pdfoutnm = outdir + us + ".pdf"
		for i in range(UTRANSID.shape[0]):
			strand = TR_EXN_STRAND_ARRAY[UTRANSID[i]][0]
			READ_S = np.array(S[np.where(UTRANSID[i] == S[:,3])][:,8], dtype='i')
			READ_E = np.array(S[np.where(UTRANSID[i] == S[:,3])][:,9], dtype='i')
			READ_ORI = np.array(S[np.where(UTRANSID[i] == S[:,3])][:,7], dtype='S').astype(str)
			TEMPLATES = np.array(S[np.where(UTRANSID[i] == S[:,3])][:,10], dtype='i')
			SS = S[np.where(UTRANSID[i] == S[:,3])]
			idx = np.argsort(READ_S)
			READ_S, READ_E, READ_ORI, TEMPLATES, SS = READ_S[idx], READ_E[idx], READ_ORI[idx], TEMPLATES[idx], SS[idx]
			EXON_SET = np.array((np.array(TR_EXN_ST_ARRAY[UTRANSID[i]]), np.array(TR_EXN_EN_ARRAY[UTRANSID[i]]))).T
			if strand == "-":
				EXON_SET = EXON_SET[::-1]
			EXON_LEN = np.array([np.abs(np.diff(EXON_SET[j])) for j in range(EXON_SET.shape[0])])
			EXON_COV = np.sum(EXON_LEN)
			EXON_COV_PERCENT = (np.array(EXON_LEN, dtype='f')/EXON_COV)*100
			exlenfactor = flankgap - (EXON_LEN.shape[0] - 1)*10
			EX_IMG_LEN = np.array((EXON_COV_PERCENT*exlenfactor)/100, dtype='i')
			READ_POS_ARRAY, READ_TMLT_ARRAY, READ_ORI_ARRAY = getReadOverlayExon(SS, READ_S, READ_E, EXON_SET, EX_IMG_LEN, TEMPLATES, READ_ORI, strand)
			tr_image_v_gap = tr_image_v_gap+120
			gene_text_pos = tr_image_v_gap + 40
			strand_text_pos_s = 40
			strand_text_pos_e = 955
			draw.text((20, gene_text_pos), "Gene ID: "+TR_GENE_ARRAY[UTRANSID[i]][0], (0,0,0), font=gnfont)
			draw.text((400, gene_text_pos), TR_CHR_ARRAY[UTRANSID[i]][0]+":"+str(np.min(np.hstack(EXON_SET)))+"-"+str(np.max(np.hstack(EXON_SET))), (0,0,0), font=gnfont)
			draw.text((800, gene_text_pos), "Transcript ID: " + UTRANSID[i], (0,0,0), font=gnfont)
			drawTranscriptTrack(EX_IMG_LEN, 50, 950, tr_image_v_gap, tr_image_v_gap, 10, 20, 10, lncolor, excolor, im, draw, strand, strand_text_pos_s, strand_text_pos_e, gnfont, READ_POS_ARRAY, READ_TMLT_ARRAY, READ_ORI_ARRAY)
		im.save(pdfoutnm, save_all=True)
			
			
GENE_TR_ARRAY, TR_CHR_ARRAY, TR_EXN_ST_ARRAY, TR_EXN_EN_ARRAY, TR_EXN_NO_ARRAY, TR_EXN_STRAND_ARRAY, TR_GENE_ARRAY = getGlobalArrays()
getGlobalArrays()

os.system('clear')

try:
	inputdir = raw_input("\t Give complete path where you uncompress the PapProject [i.e., /home/John/ExonMutViz] :: ")
	outdir = raw_input("\t Choose Only Directory where you want to store output :: ")
except:
	print("Sorry you are using Python3, so please follow the same instruction again ....")	
	inputdir = input("\t Give complete path where you uncompress the PapProject [i.e., /home/john/ExonMutViz] :: ")
	outdir = input("\t Choose Only Directory where you want to store output :: ")

outdir = outdir + "/"

fl1 = inputdir + "/input/reference_gene_models.txt"
fl2 = inputdir + "/input/input_data.txt"
getReferenceData(fl1)
getReadData(fl2, outdir)

print("\n\n\n\n\n\t\t\t\t\t------------------ Your analysis is completed ------------------")
print("\t\t\t\t\t See your output in directory :: " + outdir)

print("\n\n\n\n\n\t\t\t\t\t----------------------------------------------------------------")

